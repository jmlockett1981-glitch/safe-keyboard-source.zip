This keyboard does not collect, store, or transmit typed text. Keyboard input is delivered to the active app through Android InputMethod APIs.
